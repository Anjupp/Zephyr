#ifndef ZEPHYR_DRIVERS_ADI_AD74416H
#define ZEPHYR_DRIVERS_ADI_AD74416H

#include <zephyr/drivers/sensor.h>

// AD74416H REGISTERS

#define AD74416H_FRAME_SIZE 			5
#define AD74416H_DATA_BYTE_OFFSET       3
#define AD74416H_SCRATCH(x)			(0x76 + x)
#define AD74416H_READ_SELECT			0x6E
#define AD74416H_NOP				0x00
// #define AD74416H_OP_MODE    (SPI_MODE_CPHA | SPI_WORD_SET(8) | SPI_TRANSFER_MSB | SPI_LINES_SINGLE | SPI_OP_MODE_MASTER)
#define AD74416H_OP_MODE    ( SPI_MODE_CPOL | SPI_WORD_SET(8) | SPI_TRANSFER_MSB | SPI_LINES_SINGLE | SPI_OP_MODE_MASTER)

//configuration data
struct ad74416h_config{
    struct spi_dt_spec spi;
    uint8_t dev_addr;

};

#endif //ZEPHYR_DRIVERS_aDI_AD74416H