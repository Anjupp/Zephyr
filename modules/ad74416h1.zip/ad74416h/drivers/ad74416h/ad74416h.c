// Ties to the compatible= "adi,adt74416h" node in the devicetree
#define DT_DRV_COMPAT adi_ad74416h

#include <errno.h>
#include <zephyr/drivers/spi.h>
#include <zephyr/sys/byteorder.h>
#include <zephyr/logging/log.h>

#include "ad74416h.h"

#include <zephyr/sys/util_macro.h> 
#include <zephyr/sys/util.h>
#include <zephyr/sys/crc.h>

//Enable logging at a given level
LOG_MODULE_REGISTER(AD74416H, CONFIG_SENSOR_LOG_LEVEL);


#define AD74416H_CRC_POLYNOMIAL     0x7
#define AD74416H_DIN_DEBOUNCE_LEN   BIT(5)
#define AD77416H_DEV_ADDRESS_MSK    GENMASK(5, 4)

/********************************declaration*****************************/
static int ad74416h_init(const struct device *dev);
static int ad74416h_scratch_test(const struct device *dev);
int ad74416h_reg_write(const struct device *dev, uint32_t addr, uint16_t val);
static void ad74416h_format_reg_write(uint8_t addr, uint8_t reg, uint16_t val,
                      uint8_t *buff);


/********************************Functions*****************************/

//Formatting
static void ad74416h_format_reg_write(uint8_t addr, uint8_t reg, uint16_t val,
                      uint8_t *buff)
{
    printk("inside format reg write\r\n");
    buff[0] = FIELD_PREP(AD77416H_DEV_ADDRESS_MSK, 0x00); 
    buff[1] = reg; 
    sys_put_be16(val, &buff[2]);
    buff[4] = crc8(buff, 4, 0x07, 0x00, false);
    printk("crc done\r\n");
}

// int ad74416h_reg_read_raw(const struct device *dev, uint32_t addr, uint8_t *val)
// {
//     const struct ad74416h_config *cfg = dev->config;

//     int ret;
//     uint8_t tx_buf[AD74416H_FRAME_SIZE];
//     uint8_t rx_buf[AD74416H_FRAME_SIZE];

//     /* Prepare the READ_SELECT write frame */
//     ad74416h_format_reg_write(cfg->dev_addr, AD74416H_READ_SELECT, addr, tx_buf);

//     struct spi_buf tx = { .buf = tx_buf, .len = AD74416H_FRAME_SIZE };
//     struct spi_buf rx = { .buf = rx_buf, .len = AD74416H_FRAME_SIZE };
//     struct spi_buf_set tx_set = { .buffers = &tx, .count = 1 };
//     struct spi_buf_set rx_set = { .buffers = &rx, .count = 1 };

//     /* Send the READ_SELECT command */
//     ret = spi_transceive_dt(&cfg->spi, &tx_set, NULL);
//     if (ret < 0)
//         return ret;

//     /* Prepare the NOP frame for the second transaction */
//     ad74416h_format_reg_write(cfg->dev_addr, AD74416H_NOP, AD74416H_NOP, tx_buf);

//     /* Perform the actual read */
//     ret = spi_transceive_dt(&cfg->spi, &tx_set, &rx_set);
//     if (ret < 0)
//         return ret;

//     // /* Extract the register value */
//     // *val = rx_set[AD74416H_DATA_BYTE_OFFSET]; // Adjust offset based on AD74416H protocol

//     return 0;
// }



// Register write
int ad74416h_reg_write(const struct device *dev, uint32_t addr, uint16_t val)
{
    const struct ad74416h_config *cfg = dev->config;

    printk("inside the reg_write\n\r");
    uint8_t tx_buf[AD74416H_FRAME_SIZE];  // Transmit buffer
    uint8_t rx_buf[AD74416H_FRAME_SIZE];

    // Format write request
    ad74416h_format_reg_write(cfg->dev_addr, addr, val, tx_buf);

    struct spi_buf tx = { .buf = tx_buf, .len = AD74416H_FRAME_SIZE };
    struct spi_buf_set tx_set = { .buffers = &tx,.count = 1};
    struct spi_buf rx = { .buf = &rx_buf, .len = AD74416H_FRAME_SIZE };
    struct spi_buf_set rx_set = { .buffers = &rx,.count = 1};

    

    printk("Perform SPI write\r\n");
    // return spi_write_dt(&desc->spi, &tx_set);
    return spi_transceive_dt(&cfg->spi, &tx_set, &rx_set);
    
}


// int ad74416h_reg_read(const struct device *dev, uint32_t addr, uint16_t *val)
// {

//     // const struct ad74416h_config *cfg = dev->config;
//     uint8_t comm_buff[AD74416H_FRAME_SIZE];
//     int ret;
//     uint8_t expected_crc;
//     ret = ad74416h_reg_read_raw(dev, addr, comm_buff);
//     if (ret)
//         return ret;
//     expected_crc = crc8(comm_buff, 4, 0x07, 0x00, false); // recheck crc8
//     if (expected_crc != comm_buff[4]){
//         return -EINVAL;}
// 	*val = sys_get_be16(comm_buff[2]);
//     return 0;
// }

//scratch test
static int ad74416h_scratch_test(const struct device *dev)
{
    printk("inside the scratch\r\n");

    // const struct ad74416h_config *cfg = dev->config;

    int ret;
    uint16_t val=0x0000;
    uint16_t test_val = 0x1234;
    ret = ad74416h_reg_write(dev, AD74416H_SCRATCH(0), test_val);
    if (ret)
        return ret;
    printk("scratch write\r\n");
    // ret = ad74416h_reg_read(dev, AD74416H_SCRATCH(0), &val);
    // if (ret)
    //     return ret;
    // if (val != test_val)
    //     return -EINVAL;
    return 0;
}


//Initialize the ad74416h
static int ad74416h_init(const struct device *dev)
{
    const struct ad74416h_config *cfg = dev->config;

    int ret = 0;

    //print to console
    LOG_DBG("Initializing");

    // check the bus us ready 
    if (!device_is_ready(cfg->spi.bus)){
        LOG_ERR("Bus device is not ready");
        return -ENODEV;
    }

    //Scratch test
    while(1){
        // ksleep(50);
    ret=ad74416h_scratch_test(dev);
    }

    return ret;

}

// Expansion macro to define the driver instances
#define AD74416H_DEFINE(inst)                                                                                   \
                                                                                                                \
    /*  Create an instance of the config struct and populate with DT value*/                                    \
    static const struct ad74416h_config ad74416h_config_##inst = {                                              \
        .spi = SPI_DT_SPEC_INST_GET(inst, AD74416H_OP_MODE, 0),                                                 \
        .dev_addr = DT_INST_PROP(inst, dev_addr),                                                               \
    };                                                                                                          \
                                                                                                                \
    /*create device instances from the devicetree*/                                                             \
    DEVICE_DT_INST_DEFINE(inst,                                                                                 \
                        ad74416h_init,                                                                          \
                        NULL,                                                                                   \
                        NULL,                                                                                   \
                        &ad74416h_config_##inst,                                                                \
                        POST_KERNEL,                                                                            \
                        CONFIG_SPI_INIT_PRIORITY,                                                               \
			            NULL);                                                                                  \

DT_INST_FOREACH_STATUS_OKAY(AD74416H_DEFINE)

